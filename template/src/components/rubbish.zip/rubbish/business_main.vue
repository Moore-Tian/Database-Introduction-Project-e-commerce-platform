<template>
  <div>
    <v-row>
      <v-col></v-col>
      <v-col>
        <v-alert
            color="primary"
            dark
            icon="mdi-vuetify"
            border="left"
            prominent
            min-width="500"
        >
          欢迎xxx，您可以通过左侧导航栏查看不同页面。
        </v-alert>
      </v-col>
      <v-col></v-col>
    </v-row>
  </div>
</template>

<script>

export default {
  name: 'business_main',

  data: () => ({

  }),
};
</script>

