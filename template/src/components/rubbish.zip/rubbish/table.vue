<template>

</template>

<script>
export default {
  name: "table"
}
</script>

<style scoped>

</style>